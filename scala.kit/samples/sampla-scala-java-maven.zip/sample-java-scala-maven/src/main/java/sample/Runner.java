/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author oliver.guenther
 */
public class Runner {
 
    public void runScalaSample() {
      ScalaSample s = new ScalaSample();
      s.sample("Some Output");    
    }
    
    public static void main(String[] args) {
        new Runner().runScalaSample();
    }
}
