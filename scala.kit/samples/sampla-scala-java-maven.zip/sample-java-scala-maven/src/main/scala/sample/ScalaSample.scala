package sample

/**
 * @author ${user.name}
 */
class ScalaSample() {
  
  def sample(out:String) = println(out)

}
