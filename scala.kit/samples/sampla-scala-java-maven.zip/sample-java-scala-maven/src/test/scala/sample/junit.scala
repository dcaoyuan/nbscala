package sample

import org.junit._
import Assert._

@Test
class AppTest {

    @Test
    def testOK() {
      val a = new Runner
      a.runScalaSample
    }

//    @Test
//    def testKO() = assertTrue(false)

}


